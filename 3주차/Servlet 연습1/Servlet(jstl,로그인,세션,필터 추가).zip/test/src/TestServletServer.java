import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;

public class TestServletServer extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		
		if(session.isNew()) {
	    	//display login
	    	response.sendRedirect("http://www.naver.com");
	    }
	    else {  
	    	response.sendRedirect("http://www.daum.net");
	    }
		/*
		PrintWriter out = response.getWriter();
		java.util.Date today = new java.util.Date();
		out.println("<html> " + "<body>" + "<h1 align=center>HELLO WORD!!</h1>" + "<br>" + today + "</body>" + "</html>");
		*/
	}
}
