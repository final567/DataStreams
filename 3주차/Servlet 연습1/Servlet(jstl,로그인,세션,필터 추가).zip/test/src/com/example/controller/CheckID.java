package com.example.controller;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

import com.example.model.UserTable;

/**
 * Servlet Filter implementation class CheckID
 */
@WebFilter("/CheckID")
public class CheckID implements Filter {

    /**
     * Default constructor. 
     */
    public CheckID() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpSession session = ((HttpServletRequest)request).getSession(false);
		
		// �α��� ���� ����
	    String userID="test";
	    String userPWD="test";
	    //String userName="�̸�";
	    
	    // login.jsp�κ��� form data�� �޴´�
	    String id = request.getParameter("id");
	    String pwd = request.getParameter("password");

	    if(session==null) {
	    	if(userID.equals(id) && userPWD.equals(pwd)) {
	    		session = ((HttpServletRequest)request).getSession();
	    		((HttpServletResponse)response).sendRedirect("JoinUser");
	    	}
	    	else {
	    		RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
		    	dispatcher.forward(request, response);
	    	}
	    }
	    else {
	    	chain.doFilter(request, response);
	    }	    
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
